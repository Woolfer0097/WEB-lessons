import sys
import sqlite3

from PyQt5 import uic
from PyQt5.QtCore import QSize
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, \
    QMainWindow, QWidget, QPushButton, QListWidgetItem, \
    QMessageBox


class LibraryCatalogue(QMainWindow):
    def __init__(self):
        super().__init__()
        self.con = sqlite3.connect("databases/library_catalogue.sqlite")
        uic.loadUi("Designs/library_catalogue_main_window.ui", self)
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Каталог Библиотеки')
        self.search_btn.clicked.connect(self.search)

    def search(self):
        cursor = self.con.cursor()
        if self.info_get.text().isalpha() and not self.info_get.text().isdigit():
            if self.type_box.currentText() == "Название":
                sql_request = f"SELECT title FROM books WHERE title " \
                              f"LIKE '%{self.info_get.text()}%'"
                titles = [str(*i) for i in cursor.execute(sql_request)]
                self.fill_table(titles)
            elif self.type_box.currentText() == "Автор":
                sql_request = f"SELECT books.title FROM books LEFT JOIN authors " \
                              f"ON authors.id = books.author WHERE authors.title " \
                              f"LIKE '%{self.info_get.text()}%'"
                titles = [str(*i) for i in cursor.execute(sql_request)]
                self.fill_table(titles)
        else:
            QMessageBox.critical(self, "Ошибка ", "Неправильные данные", QMessageBox.Ok)

    def fill_table(self, data):
        self.books_table.clear()
        for item_ in data:
            btn = QPushButton(item_)
            btn.clicked.connect(self.info_widget_show)
            item = QListWidgetItem(self.books_table)
            item.setSizeHint(QSize(0, 30))
            self.books_table.setItemWidget(item, btn)

    def info_widget_show(self):
        cursor = self.con.cursor()
        sql_request = f"SELECT id FROM books WHERE title = '{self.sender().text()}'"
        id = int(*[str(*i) for i in cursor.execute(sql_request)])
        self.widget = InfoWidget(id)
        self.widget.show()


class InfoWidget(QWidget):
    def __init__(self, id_):
        super().__init__()
        uic.loadUi("Designs/library_catalogue_info_widget.ui", self)
        self.con = sqlite3.connect("databases/library_catalogue.sqlite")
        self.id = id_
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Информация о книге')
        self.set_image()
        self.set_info()

    def set_image(self):
        cursor = self.con.cursor()
        sql_request = f"SELECT image_link FROM books WHERE id = {self.id}"
        link = str(*[str(*i) for i in cursor.execute(sql_request)])
        if link == 'None':
            link = "books/standard-image.jpg"
        img = QPixmap(link)
        img_res = img.scaled(self.image.size())
        self.image.setPixmap(img_res)

    def set_info(self):
        cursor = self.con.cursor()
        sql_request = f"SELECT title FROM books WHERE id = {self.id}"
        title = str(*[str(*i) for i in cursor.execute(sql_request)])
        sql_request = f"SELECT authors.title FROM books LEFT JOIN authors " \
                      f"ON authors.id = books.author WHERE books.id = {self.id}"
        author = str(*[str(*i) for i in cursor.execute(sql_request)])
        sql_request = f"SELECT year FROM books WHERE id = {self.id}"
        year = str(*[str(*i) for i in cursor.execute(sql_request)])
        sql_request = f"SELECT genres.title FROM books LEFT JOIN genres " \
                      f"ON genres.id = books.genre WHERE books.id = {self.id}"
        genre = str(*[str(*i) for i in cursor.execute(sql_request)])
        self.title_label.setText(title)
        self.author_label.setText(author)
        self.year_label.setText(year)
        self.genre_label.setText(genre)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = LibraryCatalogue()
    ex.show()
    sys.exit(app.exec())
